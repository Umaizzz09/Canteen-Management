import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'models/contact.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Hive and register adapter
  await Hive.initFlutter();
  Hive.registerAdapter(ContactAdapter());

  // Open the Hive box
  await Hive.openBox<Contact>('contactsBox');

  runApp(const ContactBookApp());
}

class ContactBookApp extends StatelessWidget {
  const ContactBookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contact Book',
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
      home: const ContactListScreen(),
    );
  }
}

class ContactListScreen extends StatefulWidget {
  const ContactListScreen({super.key});

  @override
  State<ContactListScreen> createState() => _ContactListScreenState();
}

class _ContactListScreenState extends State<ContactListScreen> {
  late Box<Contact> contactBox;

  @override
  void initState() {
    super.initState();
    contactBox = Hive.box<Contact>('contactsBox');
  }

  void _addDummyContact() {
    final contact = Contact(name: 'John Doe', phone: '1234567890');
    contactBox.add(contact);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Contact Book')),
      body: ValueListenableBuilder(
        valueListenable: contactBox.listenable(),
        builder: (context, Box<Contact> box, _) {
          if (box.values.isEmpty) {
            return const Center(child: Text('No contacts yet.'));
          }
          return ListView.builder(
            itemCount: box.length,
            itemBuilder: (context, index) {
              final contact = box.getAt(index);
              return ListTile(
                title: Text(contact?.name ?? ''),
                subtitle: Text(contact?.phone ?? ''),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addDummyContact,
        child: const Icon(Icons.add),
      ),
    );
  }
}
