package com.example.flutte

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
